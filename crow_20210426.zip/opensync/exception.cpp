#include "exception.h"

namespace opensync
{

}