#pragma once
#include <iostream>
#include <stdio.h>
#include <string.h>

#include <boost/logic/tribool.hpp>
#include <boost/logic/tribool_io.hpp>
#include <boost/foreach.hpp>

#include "opensync_public_define.h"
#include "log4cpp_instance.h"
#include "exception.h"